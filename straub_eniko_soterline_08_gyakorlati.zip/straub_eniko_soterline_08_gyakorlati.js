const adatok=[1, 2, 3, "alma", "banán", "körte","Eniko"];
let segito="segítőd: János, kora: 31";
let nev;
let answer;

//function onclick(kuld) 
//onclick.kuld(nev=document.getElementById("name").value);
//console.error(nev);

//document.getElementById("kuld").onclick = function() {myFunction()};

onclick(document.getElementById("kuld"));

function myFunction(name,nev) {
  nev=getElementById("name").value;
};

let van = adatok.find(nev);

if (nev){
    answer="Regisztrált tag vagy, "+segito;
} else {
    answer="Nem vagy regisztrált tag, "+segito;
}

console.log(answer);

//Ez még nem működik, de lejárt az idő, úgyhogy feltöltöttem. Dolgozom még rajta, és azt a verziót is felteszem.